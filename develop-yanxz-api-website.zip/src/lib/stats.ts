import { desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { apiStats } from "@/db/schema";

export function recordHit(path: string) {
  db.insert(apiStats)
    .values({ path, hits: 1 })
    .onConflictDoUpdate({ target: apiStats.path, set: { hits: sql`${apiStats.hits} + 1`, updatedAt: new Date() } })
    .catch(() => {
      /* statistik tidak boleh mengganggu respons API */
    });
}

export async function getStats() {
  try {
    const [total] = await db.select({ total: sql<number>`coalesce(sum(${apiStats.hits}), 0)::int` }).from(apiStats);
    const top = await db.select({ path: apiStats.path, hits: apiStats.hits }).from(apiStats).orderBy(desc(apiStats.hits)).limit(5);
    return { totalRequests: total?.total ?? 0, top };
  } catch {
    return { totalRequests: 0, top: [] as { path: string; hits: number }[] };
  }
}
